$(document).ready(function () {
    $("#aml").click(function () {
        $.ajax({
            url:"php/main.php"
        })
    })
})