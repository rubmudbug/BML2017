-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 2017-09-28 18:28:55
-- 服务器版本： 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `hblog`
--

-- --------------------------------------------------------

--
-- 表的结构 `about_blog`
--

CREATE TABLE `about_blog` (
  `blog_id` mediumint(8) NOT NULL COMMENT '用户ID',
  `blog_keyword` varchar(255) NOT NULL COMMENT '博客关键字',
  `blog_description` varchar(255) NOT NULL COMMENT '博客描述',
  `blog_name` varchar(36) NOT NULL COMMENT '博客名称',
  `blog_title` varchar(128) NOT NULL COMMENT '博客标题',
  `user_id` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `article`
--

CREATE TABLE `article` (
  `article_id` smallint(5) NOT NULL COMMENT '日志自增ID号',
  `article_name` varchar(128) NOT NULL COMMENT '文章名称',
  `sort_article_id` mediumint(8) NOT NULL COMMENT '所属分类',
  `user_id` mediumint(8) NOT NULL COMMENT '所属用户ID',
  `type_id` tinyint(3) NOT NULL DEFAULT '1' COMMENT '栏目ID',
  `article_content` text NOT NULL COMMENT '文章内容',
  `article_src` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `article`
--

INSERT INTO `article` (`article_id`, `article_name`, `sort_article_id`, `user_id`, `type_id`, `article_content`, `article_src`) VALUES
(1, '', 0, 1, 1, '镇魂街，此乃吸纳亡灵镇压恶灵之地。这是一个人灵共存的世界，但不是每个人都能进入镇魂街，只有拥有守护灵的寄灵人才可进入。夏铃原本是一名普通的大学实习生，但一次偶然导致她的人生从此不再平凡。在这个充满恶灵的世界，你能与你的守护灵携手生存下去吗?', '/img/zhj.jpg'),
(2, '', 0, 1, 1, '公元XX年，新一代的军备竞争开始，“尖兵”作为一种新型的武器开始广泛的运用在军事纷争中。女主角琉璃是马上退役的尖兵。在她最后的380天里她接到了最后的任务……', '/img/cf.jpg'),
(3, '', 0, 1, 1, '根据古典小说记载，世上有人有妖，妖会与人相恋，妖寿命千万年，人的寿命有限，人死了，妖活着。人会投胎转世，但投胎以后，不记得上辈子的爱。妖如果痴情的话，就去找狐妖“购买”一项服务，让投胎转世的人，回忆起前世的爱.', '/img/hyxhn.jpg');

-- --------------------------------------------------------

--
-- 表的结构 `article_sort`
--

CREATE TABLE `article_sort` (
  `sort_article_id` mediumint(8) NOT NULL COMMENT '文章自增ID',
  `sort_article_name` varchar(60) NOT NULL COMMENT '分类名称'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- 表的结构 `photos`
--

CREATE TABLE `photos` (
  `photo_id` mediumint(8) NOT NULL COMMENT '相片ID',
  `photo_name` varchar(255) NOT NULL COMMENT '相片名称',
  `photo_src` varchar(255) NOT NULL COMMENT '图片路径',
  `photo_description` varchar(255) NOT NULL COMMENT '图片描述',
  `user_id` mediumint(8) NOT NULL COMMENT '所属用户ID'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `photos`
--

INSERT INTO `photos` (`photo_id`, `photo_name`, `photo_src`, `photo_description`, `user_id`) VALUES
(1, 'cf', '/img/cf.jpg', '雏蜂', 1),
(2, 'hyxhn', '/img/hyxhn.jpg', '狐妖小红娘', 0),
(3, 'title.png', '/img/title.png', '标题', 1),
(4, 'zhj', '/img/zhj.jpg', '镇魂街', 1);

-- --------------------------------------------------------

--
-- 表的结构 `user`
--

CREATE TABLE `user` (
  `user_id` mediumint(8) NOT NULL COMMENT '用户ID',
  `user_name` varchar(32) NOT NULL COMMENT '用户名',
  `user_pwd` varchar(32) NOT NULL COMMENT '用户密码',
  `user_phone` int(12) NOT NULL COMMENT '用户手机号码',
  `user_sex` varchar(6) NOT NULL COMMENT '用户性别',
  `user_qq` mediumint(9) NOT NULL COMMENT '用户QQ号码',
  `user_email` varchar(64) NOT NULL COMMENT '用户EMAIL地址',
  `user_description` varchar(255) NOT NULL COMMENT '自我描述',
  `user_image_url` varchar(255) NOT NULL COMMENT '用户头像存储路径'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- 转存表中的数据 `user`
--

INSERT INTO `user` (`user_id`, `user_name`, `user_pwd`, `user_phone`, `user_sex`, `user_qq`, `user_email`, `user_description`, `user_image_url`) VALUES
(1, 'root', 'root', 0, '', 0, '1192958015@qq.com', '', ''),
(2, 'test', 'test', 0, '', 0, '', '', ''),
(13, 'root', '11@qq.com', 0, '', 0, '487', '', ''),
(12, '456', '1192945@qq.com', 0, '', 0, '487', '', ''),
(11, '1455', '11233@qq.com', 0, '', 0, '1234', '', '');

-- --------------------------------------------------------

--
-- 表的结构 `user_comment`
--

CREATE TABLE `user_comment` (
  `c_id` mediumint(8) NOT NULL COMMENT '评论自增ID号',
  `user_id` mediumint(8) NOT NULL COMMENT '收到评论的用户ID',
  `type_id` tinyint(3) NOT NULL COMMENT '评论栏目ID',
  `commit_id` mediumint(8) NOT NULL COMMENT '评论内容的ID',
  `commit_content` varchar(255) NOT NULL COMMENT '评论内容',
  `commit_user_id` mediumint(8) NOT NULL COMMENT '评论者ID'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about_blog`
--
ALTER TABLE `about_blog`
  ADD PRIMARY KEY (`blog_id`);

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`article_id`);

--
-- Indexes for table `article_sort`
--
ALTER TABLE `article_sort`
  ADD PRIMARY KEY (`sort_article_id`);

--
-- Indexes for table `photos`
--
ALTER TABLE `photos`
  ADD PRIMARY KEY (`photo_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `user_comment`
--
ALTER TABLE `user_comment`
  ADD PRIMARY KEY (`c_id`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `article`
--
ALTER TABLE `article`
  MODIFY `article_id` smallint(5) NOT NULL AUTO_INCREMENT COMMENT '日志自增ID号', AUTO_INCREMENT=11;

--
-- 使用表AUTO_INCREMENT `article_sort`
--
ALTER TABLE `article_sort`
  MODIFY `sort_article_id` mediumint(8) NOT NULL AUTO_INCREMENT COMMENT '文章自增ID';

--
-- 使用表AUTO_INCREMENT `photos`
--
ALTER TABLE `photos`
  MODIFY `photo_id` mediumint(8) NOT NULL AUTO_INCREMENT COMMENT '相片ID', AUTO_INCREMENT=5;

--
-- 使用表AUTO_INCREMENT `user`
--
ALTER TABLE `user`
  MODIFY `user_id` mediumint(8) NOT NULL AUTO_INCREMENT COMMENT '用户ID', AUTO_INCREMENT=14;

--
-- 使用表AUTO_INCREMENT `user_comment`
--
ALTER TABLE `user_comment`
  MODIFY `c_id` mediumint(8) NOT NULL AUTO_INCREMENT COMMENT '评论自增ID号';
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
