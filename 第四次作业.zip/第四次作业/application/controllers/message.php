<?php
class message extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->helper('form');
        $this->load->model('image_model');
        $this->load->model('message_model');
    }

    public function index()
    {
        $data=array('title'=>'留言');
        $this->load->view('templates/header',$data);
        $this->load->view('message');
        $this->load->view('templates/footer');
    }

    public function do_text()
    {
        $this->message_model->setMessage();

    }
    public function do_message(){
        $this->image_model->setImage();
    }
}
?>