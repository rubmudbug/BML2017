<?php
/**
 * Created by PhpStorm.
 * User: Cybertron
 * Date: 2017/9/28
 * Time: 21:09
 */

class logout extends CI_Controller
{
    public function index(){

        if(!empty($_SESSION)||!isset($_SESSION)){
            $newdata = array(
                'user-name' => '未登录' ,
            );
            $this->session->set_userdata($newdata);
        }
        redirect('/');
    }

}