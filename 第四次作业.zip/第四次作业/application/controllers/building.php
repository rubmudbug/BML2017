<?php
/**
 * Created by PhpStorm.
 * User: Cybertron
 * Date: 2017/9/28
 * Time: 20:55
 */

class building extends CI_Controller
{
    public function index()
    {
        $this->load->view('building');
    }
}