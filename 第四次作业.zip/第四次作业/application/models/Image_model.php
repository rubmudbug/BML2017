<?php
/**
 * Created by PhpStorm.
 * User: Cybertron
 * Date: 2017/9/28
 * Time: 19:07
 */

class Image_model extends CI_Model
{
    private $src='/';
    public function __construct()
    {
        parent::__construct();
        $this->load->helper('url');
    }

    public function setImage()
    {
        $config['upload_path'] = './uploads/';
        $config['allowed_types'] = 'gif|jpg|png';
        $config['max_size'] = 100;
        $config['max_width'] = 1024;
        $config['max_height'] = 768;
        $config['encrypt_name']='TRUE';

        $this->load->library('upload', $config);

        $this->upload->do_upload('user-file');
            $this->src=$this->upload->data('full_path');
    }
    public function getImageSrc(){
        return $this->src;
    }
}