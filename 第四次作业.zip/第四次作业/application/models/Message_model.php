<?php
/**
 * Created by PhpStorm.
 * User: Cybertron
 * Date: 2017/9/28
 * Time: 14:11
 */

class Message_model extends CI_Model
{
    private $article=array(' ');

    public function setMessage()
    {
        if ($_SESSION['user-name'] != '未登录' && !empty($_SESSION)) {
            if ($_POST['submit'] == '发布留言') {
                $message = $this->input->post('user-article');
                $title = $this->input->post('article-name');
                $user_name = $_SESSION['user-name'];
                $query = $this->db->query("SELECT * FROM user;");
                foreach ($query->result_array() as $da) {
                    if ($da['user_name'] == $user_name) {
                        $user_id = $da['user_id'];
                    } else {
                        return false;
                    }
                }
                $this->article = array('article_name' => $title,
                    'user_id' => $user_id,
                    'article_content' => $message,
                );

                 $this->db->insert('article', $this->article);
            }
            return true;
        } else {
            $this->load->view('warning');
        }
    }

    public function getArticleName()
    {
        return $this->article['article_name'];
    }

    public function getUserId()
    {
        return $this->article['user_id'];
    }

    public function getArticleContent()
    {
        return $this->article['article_content'];
    }

}