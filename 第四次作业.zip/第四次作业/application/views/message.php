

<div class="form-group">
    <?php echo form_open('message/do_text'); ?>
    <input type="text" class="form-control" placeholder="Text input" name="article-name">
    <textarea class="form-control" rows="3" name="user-article"></textarea>
    <input type="submit" name="submit" value="发布留言">
    </form>
    <?php echo form_open_multipart('message/do_message');?>
    <div class="form-group">
        <label for="InputFile">上传图片</label>
        <input type="file" id="InputFile" name="user-file">
    </div>
    </form>
</div>
