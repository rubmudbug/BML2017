
<?php echo validation_errors(); ?>
<?php echo form_open('log/formsubmit'); ?>
<h2 class="form-signin-heading">请登录</h2>
<label for="inputUserName" class="sr-only">用户名/昵称</label>
<input type="text" id="inputUserName" class="form-control" name="username" placeholder="用户姓名" required autofocus>
<label for="inputPassword" class="sr-only">密码</label>
<input type="password" id="inputPassword" class="form-control" name="password" placeholder="密 码" required autofocus>
<input class="btn btn-lg btn-primary btn-block" type="submit" name="submit" value="login">
</form>
