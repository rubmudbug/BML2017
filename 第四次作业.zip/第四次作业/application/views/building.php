<!DOCTYPE html>
<html lang="zh-CN">
    <title>网站正在建设中....</title>

    <link rel="stylesheet" href="../../css/reset.css">
    <link rel="stylesheet" href="../../css/960.css">
    <link rel="stylesheet" href="../../css/style.css">

    <!--[if lt IE 9]>
    <link rel="stylesheet" href="css/ie.css">
    <![endif]-->

    <!-- IE fix for HTML5 tags -->
    <!--[if lt IE 9]>
    <script src="http://html5shiv.googlecode.com/svn/trunk/html5.js"></script>
    <![endif]-->

    <!-- jQuery -->
    <script src="../../js/jquery-1.7.2.min.js"></script>

    <!-- Countdown timer and other animations -->
    <script src="../../js/jquery.countdown.js"></script>
    <script src="../../js/script.js"></script>
</head>

<body quick-markup_injected="true">

<header>
    <h1 style="top: 0px;"><span class="orange">*</span> 网站正在建设中 <span class="orange">*</span></h1>
    <div id="text">
        <div class="days">天</div>
        <div class="hours">时</div>
        <div class="minutes">分</div>
        <div class="seconds">秒</div>
    </div>
    <div id="counter" class="countdownHolder"><span class="countDays"><div><p class="position"><span class="digit static" style="top: 0px; opacity: 1;">0</span></p></div><div><p class="position"><span class="digit static" style="top: 0px; opacity: 1;">9</span></p></div></span><p>:</p><span class="countDiv countDiv0"></span><span class="countHours"><div><p class="position"><span class="digit static" style="top: 0px; opacity: 1;">2</span></p></div><div><p class="position"><span class="digit static" style="top: 0px; opacity: 1;">3</span></p></div></span><p>:</p><span class="countDiv countDiv1"></span><span class="countMinutes"><div><p class="position"><span class="digit static" style="top: 0px; opacity: 1;">5</span></p></div><div><p class="position"><span class="digit static" style="top: 0px; opacity: 1;">5</span></p></div></span><p>:</p><span class="countDiv countDiv2"></span><span class="countSeconds"><div><p class="position"><span class="digit static" style="top: 0px; opacity: 1;">5</span></p></div><div><p class="position"><span class="digit static" style="top: 0px; opacity: 1;">2</span></p></div></span></div>
</header>

<div id="main" class="container_12">
    <p>邮件订阅最新动态</p>
    <div class="form-container">
        <form action="" method="get">
            <input type="text" class="email" value="输入邮箱...">
            <input type="submit" value="SIGN UP" class="submit">
        </form>
    </div>
    <div id="about_us" class="grid_4">
        <h2>关于我们</h2>
        <p>
           本人是目前是一个大二的在校学生<br>
            就读于软件工程专业<br>
            由于时间有限目前个人博客并未完全完成.<br>
            感谢你的访问,我会尽自己的努力完善个人博客的功能,并且优化代码<br>
        </p>
    </div>
    <div id="contact" class="grid_4">
        <h2>联系我们</h2>
        <p>
            <span class="gray">Email:</span> 1192958015@qq.com<br>
        </p>
    </div>
    <div id="follow_us" class="grid_4">
        <h2>关注我</h2>
        <p>
            <a class="rss" href="https://github.com/rubmudbug"></a>
        </p>
    </div>
</div>

<footer class="container_12">
    <p><span class="opacity40">* *</span> <span class="footer-orange">*</span> <span class="opacity40">* *</span></p>
</footer>

<div style=" font-size:12px; color:#BFBFBF">Prowerd By Cybertron <a href="http://www.hselfweb.cn" target="_blank" style=" font-size:12px; color:#BFBFBF">网站建设</a></div>
</body></html>