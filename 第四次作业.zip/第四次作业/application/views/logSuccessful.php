

<h3>Your form was successfully submitted!</h3>

<p><?php echo anchor('log', 'Try it again!'); ?></p>

